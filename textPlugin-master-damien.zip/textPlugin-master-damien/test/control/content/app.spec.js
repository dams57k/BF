/**
 * Created by zain on 05/01/16.
 */

describe('opentablePlugin Content: app', function () {

    describe('Buildfire service', function () {
        it('Buildfire should exists', function () {
            expect(true).toBeDefined();
        });
    });
});