# textPlugin ![](https://api.travis-ci.org/BuildFire/textPlugin.svg)
